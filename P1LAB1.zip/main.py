# CTI 110
# P1LAB1
# Ethan
# Cartwright
# 09/16/2021

# 7.12 from zybooks

userNum = int(input())
userNumSquared = userNum * userNum   # Math Bug fixed
   
print(userNumSquared)       # Output input fixed