#P5T2 - Lists and Functions 
# Ethan Cartwright
# 11/9/21


def makeListOfSize(size):
  """
  makes a list from user entered nums.
  returns a list
  """
  newList = []
  for i in range(size):
    num = int(input("Enter a number :"))
    newList.append(num)

  return newList

def displayList(items):
  """
  displays a list of user enetered numbers
  """
  for item in items:
    print(item)

def removeDupes(items):
  mySet = set(items)
  noDupeList = list(mySet)
  return noDupeList

def GetMinAndMax(numbers):
  """
  input: a list of numbers
  output: min and max of numbers
  """
  minNum = min(numbers)
  maxNum = max(numbers)
  return minNum, maxNum

def avgOfNumbers(numbers):
  """
  input: numbers of a list
  ouput: avg of all numbers and total
  """
  total = 0 
  for number in numbers:
    total += number
  average = total /len(numbers)
  return total, average
  return
#start 
def main():
  print("Making a list...")
  size = int(input("How many items in the list? "))
  numbers = makeListOfSize(size)
  print("Displaying the list...")
  displayList(numbers)
  #no dupes
  print("Removing duplicates...")
  numbersNoDupes = removeDupes(numbers)
  displayList(numbersNoDupes)
  #min and max
  minNum, maxNum = GetMinAndMax(numbers)
  print("Smallest Number In List:", minNum)
  print("Largest Number in List: ", maxNum)
# average and total
  total, average = avgOfNumbers(numbers)
  print("total = ", total, "average = ", average )
  print("Done.")
main() 